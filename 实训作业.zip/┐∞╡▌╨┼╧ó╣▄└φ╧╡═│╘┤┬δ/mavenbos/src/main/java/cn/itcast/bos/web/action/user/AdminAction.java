package cn.itcast.bos.web.action.user;

import cn.itcast.bos.domain.user.User;
import cn.itcast.bos.page.PageRequestBean;
import cn.itcast.bos.page.PageResponseBean;
import cn.itcast.bos.web.action.base.BaseAction;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ModelDriven;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.criterion.DetachedCriteria;

public class AdminAction  extends BaseAction implements ModelDriven<User> {
    // 模型驱动
    private User user = new User();

    @Override
    public User getModel() {
        return user;
    }

    // 业务方法 --- 分页列表查询
    public String pageQuery() {
        // 条件对象
        DetachedCriteria detachedCriteria = DetachedCriteria.forClass(User.class);
        PageRequestBean pageRequestBean = initPageRequestBean(detachedCriteria);

        // 调用业务层，进行查询 结果PageResponseBean
        PageResponseBean pageResponseBean = userService.pageQuery(pageRequestBean);

        // 将结果 转换 json
        ActionContext.getContext().put("pageResponseBean", pageResponseBean);

        return "pageQuerySUCCESS";
    }

    // 业务方法 --- 保存或修改 取派员
    public String saveOrUpdate() {
        if("admin".equals(user.getUsername())){
            return SUCCESS;
        }
        if(StringUtils.isBlank(user.getPassword())){
            user.setPassword("e10adc3949ba59abbe56e057f20f883e");
        }
        userService.saveOrUpdate(user);

        return SUCCESS;
    }

    // 业务方法 --- 批量删除
    public String delBatch() {
        String[] ids = user.getId().split(", ");
        // 调用业务层，作废
        userService.updateStationBatch(ids,"作废");

        return SUCCESS;
    }

    public String enableBatch() {
        String[] ids = user.getId().split(", ");
        userService.updateStationBatch(ids,"正常");

        return SUCCESS;
    }



}
