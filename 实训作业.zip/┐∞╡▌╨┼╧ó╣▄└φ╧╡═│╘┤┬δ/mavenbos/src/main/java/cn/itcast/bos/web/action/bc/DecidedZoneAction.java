package cn.itcast.bos.web.action.bc;

import java.util.List;

import cn.itcast.bos.domain.bc.Region;
import cn.itcast.bos.domain.user.User;
import org.apache.struts2.ServletActionContext;
import org.hibernate.criterion.DetachedCriteria;

import cn.itcast.bos.domain.bc.DecidedZone;
import cn.itcast.bos.page.PageRequestBean;
import cn.itcast.bos.page.PageResponseBean;
import cn.itcast.bos.web.action.base.BaseAction;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ModelDriven;
import org.hibernate.criterion.Restrictions;

/**
 * 定区管理
 * 
 * @author seawind
 * 
 */
public class DecidedZoneAction extends BaseAction implements ModelDriven<DecidedZone> {

	// 模型驱动
	private DecidedZone decidedZone = new DecidedZone();

	@Override
	public DecidedZone getModel() {
		return decidedZone;
	}

	// 业务方法 ---- 添加、修改 定区
	public String saveOrUpdate() {
		User user = (User) ServletActionContext.getRequest().getSession().getAttribute("user");
		decidedZone.setUser(user);
		// 调用业务层 ，添加定区
		decidedZoneService.saveOrUpdate(decidedZone, subareaId);
		return "saveOrUpdateSUCCESS";
	}

	// 属性驱动 接收关联分区id
	private String[] subareaId;

	public void setSubareaId(String[] subareaId) {
		this.subareaId = subareaId;
	}

	// 业务方法 --- 定区分页查询
	public String pageQuery() {
		// 封装 PageRequestBean
		DetachedCriteria detachedCriteria = DetachedCriteria.forClass(DecidedZone.class);
		User user = (User) ServletActionContext.getRequest().getSession().getAttribute("user");
		detachedCriteria.add(Restrictions.eq("user",user));
		PageRequestBean pageRequestBean = initPageRequestBean(detachedCriteria);



		PageResponseBean pageResponseBean = decidedZoneService.pageQuery(pageRequestBean);
		// 压入值栈返回
		ActionContext.getContext().put("pageResponseBean", pageResponseBean);

		return "pageQuerySUCCESS";
	}

	// 属性驱动接收多个客户id
	private String[] customerIds;

	public void setCustomerIds(String[] customerIds) {
		this.customerIds = customerIds;
	}

}
