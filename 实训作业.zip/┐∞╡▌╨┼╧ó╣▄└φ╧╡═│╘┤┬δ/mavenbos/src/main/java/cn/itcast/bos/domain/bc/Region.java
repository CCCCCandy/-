package cn.itcast.bos.domain.bc;

import java.util.HashSet;
import java.util.Set;

import cn.itcast.bos.domain.user.User;
import org.apache.struts2.json.annotations.JSON;

/**
 * 区域信息 Region entity. @author MyEclipse Persistence Tools
 */

public class Region implements java.io.Serializable {

	// Fields

	private Long id; // 编号 （assigned 委派）
	private User user; // 操作人 （由谁制定标准，当前登陆用户 ）

	private String province; // 省份
	private String city; // 城市
	private String district; // 区域
	private String postcode; // 邮编
	private String shortcode; // 简码 （拼音缩写 ： 北京 BJ）
	private String citycode; // 城市编码 (拼音全拼 北京 beijing )

	private Set subareas = new HashSet(0); // 关联分区

	// Constructors

	/** default constructor */
	public Region() {
	}

	/** minimal constructor */
	public Region(Long id) {
		this.id = id;
	}

	public Region(Long id, User user, String province, String city, String district, String postcode, String shortcode, String citycode, Set subareas) {
		this.id = id;
		this.user = user;
		this.province = province;
		this.city = city;
		this.district = district;
		this.postcode = postcode;
		this.shortcode = shortcode;
		this.citycode = citycode;
		this.subareas = subareas;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	/** full constructor */


	// Property accessors

	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getProvince() {
		return this.province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getCity() {
		return this.city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getDistrict() {
		return this.district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getPostcode() {
		return this.postcode;
	}

	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}

	public String getShortcode() {
		return this.shortcode;
	}

	public void setShortcode(String shortcode) {
		this.shortcode = shortcode;
	}

	public String getCitycode() {
		return this.citycode;
	}

	public void setCitycode(String citycode) {
		this.citycode = citycode;
	}

	@JSON(serialize = false)
	public Set getSubareas() {
		return this.subareas;
	}

	public void setSubareas(Set subareas) {
		this.subareas = subareas;
	}

	// 自定义方法
	public String getInfo() {
		// 返回省市区信息
		return province + "," + city + "," + district;
	}

}