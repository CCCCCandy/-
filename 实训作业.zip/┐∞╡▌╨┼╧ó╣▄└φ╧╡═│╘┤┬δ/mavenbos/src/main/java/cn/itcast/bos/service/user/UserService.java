package cn.itcast.bos.service.user;

import cn.itcast.bos.domain.user.User;
import cn.itcast.bos.page.PageQuery;

/**
 * 用户管理 业务接口
 *
 * @author seawind
 */
public interface UserService extends PageQuery {

    // 登陆
    User login(User user);

    // 修改密码
    void editPassword(User user);

    void updateStationBatch(String[] ids, String station);

    void saveOrUpdate(User user);

}
