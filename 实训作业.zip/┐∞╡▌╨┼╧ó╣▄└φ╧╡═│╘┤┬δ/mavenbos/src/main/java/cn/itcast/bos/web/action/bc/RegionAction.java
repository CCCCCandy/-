package cn.itcast.bos.web.action.bc;

import cn.itcast.bos.domain.bc.Region;
import cn.itcast.bos.domain.user.User;
import cn.itcast.bos.page.PageRequestBean;
import cn.itcast.bos.page.PageResponseBean;
import cn.itcast.bos.web.action.base.BaseAction;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ModelDriven;
import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;

import java.util.List;

/**
 * 区域管理
 * 
 * @author seawind
 * 
 */
public class RegionAction extends BaseAction implements ModelDriven<Region> {

	// 使用log4j 日志记录器，记录日志
	private static final Logger LOG = Logger.getLogger(RegionAction.class);

	// 模型驱动
	private Region region = new Region();

	@Override
	public Region getModel() {
		return region;
	}

	// 业务方法 --- 保存区域
	public String save() {
		// 调用业务层保存数
		User user = (User) ServletActionContext.getRequest().getSession().getAttribute("user");
		region.setUser(user);
		regionService.saveRegion(region);
		return "saveSUCCESS";
	}

	// 业务方法 --- 分页列表查询
	public String pageQuery() {
		// 封装PageRequestBean
		DetachedCriteria detachedCriteria = DetachedCriteria.forClass(Region.class);
		PageRequestBean pageRequestBean = initPageRequestBean(detachedCriteria);

		// 调用业务层 ，查询PageReponseBean对象
		User user = (User) ServletActionContext.getRequest().getSession().getAttribute("user");
		DetachedCriteria dc = DetachedCriteria.forClass(Region.class);
		dc.add(Restrictions.eq("user",user));
		pageRequestBean.setDetachedCriteria(dc);
		PageResponseBean pageResponseBean = regionService.pageQuery(pageRequestBean);

		// 将结果转换为json
		ActionContext.getContext().put("pageResponseBean", pageResponseBean);

		return "pageQuerySUCCESS";
	}
	// 业务方法 ---- 查询所有区域，转换json列表
		public String ajaxlist() {
			// 调用业务层，查询所有区域信息
			User user = (User) ServletActionContext.getRequest().getSession().getAttribute("user");
			List<Region> regions = regionService.findAllRegionsByUserId(user);

			// 将查询结果 转换 json格式
			ActionContext.getContext().put("regions", regions);// 压入struts2 值栈
			return "ajaxlistSUCCESS";
		}
}
