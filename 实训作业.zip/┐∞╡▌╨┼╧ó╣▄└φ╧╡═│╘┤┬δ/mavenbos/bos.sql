/*
 Navicat Premium Data Transfer

 Source Server         : hyb
 Source Server Type    : MySQL
 Source Server Version : 50719
 Source Host           : 111.231.250.50:3306
 Source Schema         : bos

 Target Server Type    : MySQL
 Target Server Version : 50719
 File Encoding         : 65001

 Date: 10/02/2020 16:57:30
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for bc_decidedzone
-- ----------------------------
DROP TABLE IF EXISTS `bc_decidedzone`;
CREATE TABLE `bc_decidedzone`  (
  `id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `staff_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `name` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `FK66A3C8AA8019D5CE`(`staff_id`) USING BTREE,
  CONSTRAINT `FK66A3C8AA8019D5CE` FOREIGN KEY (`staff_id`) REFERENCES `bc_staff` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of bc_decidedzone
-- ----------------------------
INSERT INTO `bc_decidedzone` VALUES ('001', '001', '龙湖镇');
INSERT INTO `bc_decidedzone` VALUES ('002', '002', '河南工程学院');
INSERT INTO `bc_decidedzone` VALUES ('003', '004', '龙湖广场');
INSERT INTO `bc_decidedzone` VALUES ('004', '006', '清华大学');
INSERT INTO `bc_decidedzone` VALUES ('005', '002', '圆明园');
INSERT INTO `bc_decidedzone` VALUES ('006', '001', '科技大学');
INSERT INTO `bc_decidedzone` VALUES ('008', '002', '华联超市');
INSERT INTO `bc_decidedzone` VALUES ('009', '002', '升达大学');
INSERT INTO `bc_decidedzone` VALUES ('010', '005', '明月湖');
INSERT INTO `bc_decidedzone` VALUES ('011', '002', '信商');
INSERT INTO `bc_decidedzone` VALUES ('012', '002', '哈哈哈哈');
INSERT INTO `bc_decidedzone` VALUES ('015', '002', '西湖区');
INSERT INTO `bc_decidedzone` VALUES ('020', '002', '工业大学');
INSERT INTO `bc_decidedzone` VALUES ('021', '003', '安监局');
INSERT INTO `bc_decidedzone` VALUES ('44564', '002', '火车站');

-- ----------------------------
-- Table structure for bc_region
-- ----------------------------
DROP TABLE IF EXISTS `bc_region`;
CREATE TABLE `bc_region`  (
  `id` bigint(32) NOT NULL AUTO_INCREMENT,
  `province` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `district` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `postcode` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `shortcode` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `citycode` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 21 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of bc_region
-- ----------------------------
INSERT INTO `bc_region` VALUES (1, '河南省', '郑州市', '金水区', '566798', '金水区', 'jinshui');
INSERT INTO `bc_region` VALUES (2, '河南省', '郑州市', '二七区', '761525', '二七区', 'erqi');
INSERT INTO `bc_region` VALUES (3, '北京市', '北京市', '海淀区', '625355', '海淀区', 'haidian');
INSERT INTO `bc_region` VALUES (4, '天津市', '天津市', '南开区', '300000', '南开区', 'nankai');
INSERT INTO `bc_region` VALUES (5, '河南省', '洛阳市', '伊滨区', '776616', '伊滨区', 'yibin');
INSERT INTO `bc_region` VALUES (6, '天津市', '天津市', '西青区', '556651', '西青区', 'xiqing');
INSERT INTO `bc_region` VALUES (15, '河南省', '安阳市', '文峰区', '621313', '文峰区', 'wenfeng');
INSERT INTO `bc_region` VALUES (16, '江西省', '南昌市', '西湖区', '281731', '西湖区', 'xihu');
INSERT INTO `bc_region` VALUES (17, '黑龙江省', '哈尔滨市', '太平区', '162514', '太平区', 'taiping');
INSERT INTO `bc_region` VALUES (18, '江苏省', '南京市', '江宁区', '146134', '江宁区', 'jiangning');
INSERT INTO `bc_region` VALUES (19, '河南省', '郑州', '高新区', '112321', '高新', 'gaoxin');
INSERT INTO `bc_region` VALUES (20, '河南省', '郑州市', '中原区', '112332', '中原', 'zhongyuan');

-- ----------------------------
-- Table structure for bc_staff
-- ----------------------------
DROP TABLE IF EXISTS `bc_staff`;
CREATE TABLE `bc_staff`  (
  `id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `standard_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `name` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `telephone` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `haspda` varchar(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `deltag` varchar(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `station` varchar(40) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `FKE1E33D62180FE406`(`standard_id`) USING BTREE,
  CONSTRAINT `FKE1E33D62180FE406` FOREIGN KEY (`standard_id`) REFERENCES `bc_standard` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of bc_staff
-- ----------------------------
INSERT INTO `bc_staff` VALUES ('001', '402881f453faaada0153fb0dd4930001', '张三', '11222', '1', '0', '圆通公司');
INSERT INTO `bc_staff` VALUES ('002', '4028810753d223540153d232e5af0002', '李四', '51351345617', NULL, '0', '圆通公司');
INSERT INTO `bc_staff` VALUES ('003', '4028810753d61e8c0153d70c142f0001', '王往', '6253714', '1', '0', '韵达公司');
INSERT INTO `bc_staff` VALUES ('004', '4028810753d223540153d2331dbc0003', '刘集', '183683616', NULL, '0', '申通公司');
INSERT INTO `bc_staff` VALUES ('005', '4028810753d223540153d2331dbc0003', '张俪', '17366867', '1', '1', '韵达公司');
INSERT INTO `bc_staff` VALUES ('006', '402881f453faaada0153fb0dd4930001', '王五', '14615738·', '1', '0', '韵达公司');
INSERT INTO `bc_staff` VALUES ('007', '4028810753d61e8c0153d70c142f0001', '刘莉', '13567828876', '1', '1', '汇通公司');
INSERT INTO `bc_staff` VALUES ('008', '4028810753d61e8c0153d6230c350000', '孙六', '13132414513', '1', '1', '韵达公司');
INSERT INTO `bc_staff` VALUES ('0230', '4028810753d5e62b0153d5e6f8fa0000', 'ha1', '111', '1', '1', 'safd');
INSERT INTO `bc_staff` VALUES ('055', '402880e6702d738001702d7d2e460000', '张六', '135988884545', '1', '0', '申通公司');

-- ----------------------------
-- Table structure for bc_standard
-- ----------------------------
DROP TABLE IF EXISTS `bc_standard`;
CREATE TABLE `bc_standard`  (
  `id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `user_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `name` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `minweight` double NULL DEFAULT NULL,
  `maxweight` double NULL DEFAULT NULL,
  `deltag` varchar(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `updatetime` datetime(0) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `FKCB957CFB1C250A3C`(`user_id`) USING BTREE,
  CONSTRAINT `FKCB957CFB1C250A3C` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of bc_standard
-- ----------------------------
INSERT INTO `bc_standard` VALUES ('402880e6702d738001702d7d2e460000', '001', '当日送达', 10, 22, '0', '2020-02-10 13:05:43');
INSERT INTO `bc_standard` VALUES ('402880e6702d738001702d9335bd0001', '001', '次日送达', 20, 50, '0', '2020-02-10 13:29:47');
INSERT INTO `bc_standard` VALUES ('402880e6702e4b7901702e4da4520000', '001', '半日送达', 2, 19, '0', '2020-02-10 16:53:25');
INSERT INTO `bc_standard` VALUES ('402880e85489f34501548a0826b80000', '001', '018', 10, 200, '1', '2019-05-07 17:39:44');
INSERT INTO `bc_standard` VALUES ('4028810753d223540153d231b56d0000', '001', '001', 30, 90, '0', '2019-06-01 08:18:59');
INSERT INTO `bc_standard` VALUES ('4028810753d223540153d23255860001', '001', '002', 10, 50, '1', '2019-04-01 22:20:27');
INSERT INTO `bc_standard` VALUES ('4028810753d223540153d232e5af0002', '001', '002', 10, 50, '1', '2019-04-01 22:21:04');
INSERT INTO `bc_standard` VALUES ('4028810753d223540153d2331dbc0003', '001', '003', 20, 70, '1', '2019-04-01 22:21:18');
INSERT INTO `bc_standard` VALUES ('4028810753d223540153d2335e560004', '001', '003', 30, 70, '1', '2019-04-01 22:21:35');
INSERT INTO `bc_standard` VALUES ('4028810753d5e62b0153d5e6f8fa0000', '001', '004', 10, 100, '0', '2019-04-02 15:36:37');
INSERT INTO `bc_standard` VALUES ('4028810753d5e62b0153d5e7369a0001', '001', '005', 10, 100, '0', '2019-04-02 15:36:53');
INSERT INTO `bc_standard` VALUES ('4028810753d5e62b0153d5e766820002', '001', '006', 10, 200, '0', '2019-04-02 15:37:05');
INSERT INTO `bc_standard` VALUES ('4028810753d61e8c0153d6230c350000', '001', '007', 10, 70, '0', '2019-04-02 16:42:14');
INSERT INTO `bc_standard` VALUES ('4028810753d61e8c0153d70c142f0001', '001', '008', 20, 90, '1', '2019-04-02 20:56:46');
INSERT INTO `bc_standard` VALUES ('402881f453faaada0153fab21e990000', '001', '009', 10, 99, '1', '2019-04-09 19:04:50');
INSERT INTO `bc_standard` VALUES ('402881f453faaada0153fb0dd4930001', '001', '010', 20, 90, '0', '2019-04-16 17:45:35');
INSERT INTO `bc_standard` VALUES ('402881f4541e05d001541e75af730000', '001', '002', 20, 40, '1', '2019-04-16 17:45:09');
INSERT INTO `bc_standard` VALUES ('ff808081550941e4015509537ec70000', '001', '019', 12, 30, '0', '2019-06-01 08:18:34');

-- ----------------------------
-- Table structure for bc_subarea
-- ----------------------------
DROP TABLE IF EXISTS `bc_subarea`;
CREATE TABLE `bc_subarea`  (
  `id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `decidedzone_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `region_id` bigint(32) NULL DEFAULT NULL,
  `addresskey` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `startnum` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `endnum` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `single` varchar(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `position` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `FKF7CA50CF7A1255EE`(`decidedzone_id`) USING BTREE,
  INDEX `FKF7CA50CF192ECFA6`(`region_id`) USING BTREE,
  CONSTRAINT `FKF7CA50CF7A1255EE` FOREIGN KEY (`decidedzone_id`) REFERENCES `bc_decidedzone` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FKF7CA50CF192ECFA6` FOREIGN KEY (`region_id`) REFERENCES `bc_region` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of bc_subarea
-- ----------------------------
INSERT INTO `bc_subarea` VALUES ('001', '001', 1, '金水区', '001', '003', '0', '金水区附近');
INSERT INTO `bc_subarea` VALUES ('002', '002', 2, '二七区', '001', '008', '0', '二七广场');
INSERT INTO `bc_subarea` VALUES ('003', '004', 3, '海淀区', '004', '009', '0', '海淀区地铁附近');
INSERT INTO `bc_subarea` VALUES ('004', '015', 2, '二七区', '007', '020', '0', '二七');
INSERT INTO `bc_subarea` VALUES ('005', '003', 2, '二七区', '001', '009', '0', '二七广场');
INSERT INTO `bc_subarea` VALUES ('006', '010', 1, '金水区', '001', '008', '0', '二七广场');
INSERT INTO `bc_subarea` VALUES ('007', '011', 6, '西青', '001', '009', '0', '南开大学');
INSERT INTO `bc_subarea` VALUES ('009', '008', 1, '金水区', '004', '009', '0', '火车站');
INSERT INTO `bc_subarea` VALUES ('010', '009', 2, '哈哈', '003', '009', '0', '龙湖广场');
INSERT INTO `bc_subarea` VALUES ('011', '012', 5, '伊滨区', '001', '050', '0', '体育中心');
INSERT INTO `bc_subarea` VALUES ('012', '44564', 17, '轻物件', '002', '400', '0', '二七广场');
INSERT INTO `bc_subarea` VALUES ('018', NULL, 20, '轻物件', '002', '112', '0', '中');
INSERT INTO `bc_subarea` VALUES ('019', '021', 19, '轻物件', '002', '1122', '0', '中');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `username` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `password` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `salary` double NULL DEFAULT NULL,
  `birthday` datetime(0) NULL DEFAULT NULL,
  `gender` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `station` varchar(40) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `telephone` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `remark` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('001', 'admin', 'e10adc3949ba59abbe56e057f20f883e', 22, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user` VALUES ('002', 'zs', 'e10adc3949ba59abbe56e057f20f883e', 6666, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user` VALUES ('003', 'ls', '21232f297a57a5a743894a0e4a801fc3', 555, NULL, NULL, NULL, NULL, NULL);

SET FOREIGN_KEY_CHECKS = 1;
